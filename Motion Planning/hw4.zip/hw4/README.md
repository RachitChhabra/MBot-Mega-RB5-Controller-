# CSE276A FA22 HW4

All files are in /rb5_control/src/

1. We only need to change the mode 'm' in homework4.py file at line 276 to run each algorithm.
	
	m = "min_distance" for shortest path problem
	m = "max_safety" for safest path


2. generate_map is used to generate the map as shown in the report.
3. astar.py file calls both  the voronoi and A star functions and also functions to visualize the graphs.
4. robotplanner.py file has the A star algorithm in it.
