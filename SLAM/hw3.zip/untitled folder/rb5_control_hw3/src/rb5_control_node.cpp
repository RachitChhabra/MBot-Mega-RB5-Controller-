#include <bits/stdc++.h>
#include "rb5_control.h"


Rb5Control::Rb5Control(){
  return;
}
Rb5Control::~Rb5Control(){
  return;
}


int main(){
  Rb5Control c_obj;
  return 0; 
}
